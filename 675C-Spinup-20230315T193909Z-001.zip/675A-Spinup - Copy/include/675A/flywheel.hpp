#include "api.h"

void flywheel_pid_control();
void flywheel_aysnc_pid_control(int target_speed);
void flywheel_pid(double target_speed);