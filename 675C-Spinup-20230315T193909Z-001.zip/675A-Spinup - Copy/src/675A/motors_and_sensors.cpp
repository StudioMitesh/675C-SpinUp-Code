#include "main.h"



//------------------MOTORS------------------//
pros::Motor intake_roller(1, MOTOR_GEARSET_6, false, MOTOR_ENCODER_DEGREES);
//pros::Motor fly(7,true);

pros::Motor fly(7, MOTOR_GEARSET_36, true, MOTOR_ENCODER_DEGREES);


//------------------PNEUMATICS------------------//
pros::ADIDigitalOut pneumaticLeft('A', false);
pros::ADIDigitalOut pneumaticRight('B', false);

pros::ADIDigitalOut tray1('C', true);       //double-acting pistons are extended ("on" meaning bool is 1)
pros::ADIDigitalOut tray2('D', true);       //double-acting pistons are extended ("on" meaning bool is 1)
pros::ADIDigitalOut tilter('E', false);     //double-acting pistons are extended ("on" meaning bool is 1)

