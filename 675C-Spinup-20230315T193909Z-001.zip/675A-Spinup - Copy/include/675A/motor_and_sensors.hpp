#include "api.h"
#include "pros/vision.h"

extern pros::Motor intake_roller;
extern pros::Motor fly;

extern pros::ADIDigitalOut pneumaticRight;
extern pros::ADIDigitalOut pneumaticLeft;

extern pros::ADIDigitalOut tray1;
extern pros::ADIDigitalOut tray2;

extern pros::ADIDigitalOut tilter;

//extern pros::vision_object_s_t Vision;
