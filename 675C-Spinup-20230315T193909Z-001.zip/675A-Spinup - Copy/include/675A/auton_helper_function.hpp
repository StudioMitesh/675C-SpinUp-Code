#include "api.h"
extern bool drive_lock_enabled;
extern bool pneumatics;

void intake_in();
void intake_out();
void intake_stop();

void shoot();

void roller_forward();
void roller_backwards();
void roller_stop();


void fly_spin(int flyspeed);
void fly_rev();
void fly_stop();
void fly_idle();

void tray_up();

void expansion_launch();

void toggle_drive_lock();

void tilter_up();
void tilter_down();

//void intake_task();