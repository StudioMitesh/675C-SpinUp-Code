#include "main.h"
#include "pros/misc.h"

//Bot Functions------------------------
//#include "motors_and_sensors.cpp"
//Intake, Roller, and Shooter Control------------------------

//Flywheel Control------------------------


    int td_task(){
    tray1.set_value(true);
    tray2.set_value(true);
    pneumatics = true;

    return 0;
}




void tray_down(){
    pros::Task td(td_task);
}


void intake_control() {
  if (master.get_digital(pros::E_CONTROLLER_DIGITAL_L1) == 1) {
    intake_out();
  } else if (master.get_digital(pros::E_CONTROLLER_DIGITAL_L2) == 1) {
    intake_in();
    tray_down();
  } else {
    intake_stop();
  }
}

void skills_test()
{
  if(master.get_digital(pros::E_CONTROLLER_DIGITAL_A)==1)
  {
  const double high_speed_multiplier = 4.5, low_speed_multiplier = 1;
  const int drive_speed = 25, turn_speed = 90, swing_speed = 90;
  int flyspeed = 8000;
  fly_spin(flyspeed);
  chassis.set_drive_pid(-5,drive_speed * low_speed_multiplier); 
  chassis.wait_drive();
  roller_forward();
  pros::delay(700);
  roller_stop();
  pros::delay(200);
  chassis.set_turn_pid(-52, drive_speed*low_speed_multiplier);
  chassis.wait_drive();
  roller_forward();
  chassis.set_drive_pid(25, drive_speed*low_speed_multiplier);
  chassis.wait_drive();
  }

}


//The flywheel will constantly be spinning throughout the entire match to reduce time between shots.
void fly_control() {
  int flyspeed = 7950;
  //fly_spin();
if (master.get_digital(pros::E_CONTROLLER_DIGITAL_R1) == 1) {
    tray_up();
  } else if (master.get_digital(pros::E_CONTROLLER_DIGITAL_R2) == 1){
    tray_down();
  } 
    
   else if (master.get_digital(pros::E_CONTROLLER_DIGITAL_B) == 1 && master.get_digital(pros::E_CONTROLLER_DIGITAL_R2)) {
    //R2 AND B reverses Flywheel
    fly_rev();
  } else if (master.get_digital(pros::E_CONTROLLER_DIGITAL_B) == 1 && master.get_digital(pros::E_CONTROLLER_DIGITAL_L2)) {
    //L2 AND B stop the Flywheel
    fly_stop();
    
  }
  /*
if(master.get_digital(pros::E_CONTROLLER_DIGITAL_UP)==1)
{
  flyspeed += 1000;
  master.rumble(". .");
}
if(master.get_digital(pros::E_CONTROLLER_DIGITAL_LEFT)==1)
{
  flyspeed -= 1000;
  fly_spin(flyspeed);
  master.rumble(". .");
}
*/

}

//Expansion Control------------------------

void expansion_control() {
  if (master.get_digital(pros::E_CONTROLLER_DIGITAL_LEFT) == 1 && master.get_digital(pros::E_CONTROLLER_DIGITAL_UP) == 1) {
    expansion_launch();
    
  }
}

void roller_control(){
  if (master.get_digital(pros::E_CONTROLLER_DIGITAL_X) == 1){
    roller_forward();

  }
}

//Drive Lock------------------------

void drive_lock() {
  if (master.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_Y)){
    toggle_drive_lock();
  }
}


//Tilter Control



