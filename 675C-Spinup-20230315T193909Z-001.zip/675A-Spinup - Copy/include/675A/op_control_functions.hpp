#include "api.h"

extern bool drive_lock_enabled;
extern bool pneumatics;
extern int flyspeed;

//Bot Functions
void tray_down();
void intake_control();
void expansion_control();
void fly_control();
void roller_control();

void drive_lock();

void tilter_control();

void skills_test();