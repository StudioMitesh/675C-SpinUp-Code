#include "main.h"
bool pneumatics = false;
bool drive_lock_enabled = false;

//Intake, Shooter, and Roller Code-----------------------------------------
//Intake, Shooter, and Roller are all on a single motor. Multiple functions are made to make auton easier to visualize.

void intake_in() {
    intake_roller.move_voltage(-12000);
}

void intake_out() {
    intake_roller.move_voltage(12000);
}

void intake_stop() {
    intake_roller.move_velocity(0);
}

void shoot() {
    intake_roller.move_relative(400, 600);
}

void roller_forward() {
    intake_roller.move_voltage(-6000);
}

void roller_backwards() {
    intake_roller.move_voltage(6000);
}

void roller_stop() {
    intake_roller.move_velocity(0);
}

void fly_spin(int flyspeed) {
    fly.move_voltage(flyspeed);
}

void fly_spin_first() {
    fly.move_voltage(9600);

}

void fly_spin_third() {
    fly.move_voltage(8300);
}

void fly_spin_tongue() {
    fly.move_voltage(7800);
}


void shoot_first() {
    intake_roller.move_relative(400, 500);
}

//Flywheel Code-----------------------------------------

int fr_task() {
    fly.move_voltage(-6000);
    tray1.set_value(true);
    tray2.set_value(true);
    pneumatics = true;

    return 1;
}

//Reverses the flywheel incase there's a disk that gets jammed.
void fly_rev() {
    pros::Task fr(fr_task);
}

int fs_task() {
    fly.move_voltage(-6000);
    tray1.set_value(false);
    tray2.set_value(false);
    pneumatics = false;

    return 1;
}

//Stops the flywheel incase there's a disk that gets jammed.
void fly_stop() {
    pros::Task fs(fs_task);
}

//So the bot basically uses the intake as the indexer. The tray area holding the disks will rotate up after intaking and
//use the top intake wheels to roll the disk forward. 
int tu_task() {
    tray1.set_value(false);
    tray2.set_value(false);
    pneumatics = false;

    return 1;
}

void tray_up() {
    pros::Task tu(tu_task);
}


//Expansion Code-----------------------------------------

int el_task() {
    pneumaticLeft.set_value(true);
    pneumaticRight.set_value(true);
    pneumatics = true;

    return 1;
}

void expansion_launch() {
    pros::Task el(el_task);
}

//Drive Lock-----------------------------------------

int dl_task() {
  if(drive_lock_enabled) {
    drive_lock_enabled=!drive_lock_enabled;
    chassis.set_drive_brake(MOTOR_BRAKE_COAST);
    chassis.set_active_brake(0.0);
    master.rumble("-");
  }
  else{
    drive_lock_enabled=!drive_lock_enabled;
    chassis.set_drive_brake(MOTOR_BRAKE_HOLD);
    chassis.reset_drive_sensor();
    chassis.set_active_brake(0.1);
    master.rumble("..");
  }

  return 1;
}

void toggle_drive_lock() {
    pros::Task dl(dl_task);
}

//Tilter Code-----------------------------------------

int ti_task() {
    tilter.set_value(true);
    pneumatics = true;

    return 1;
}

void tilter_up() {
    //fly_stop();
    pros::Task tu(ti_task);
}

int tm_task(){
    tilter.set_value(false);
    pneumatics = false;

    return 0;
}

void tilter_down()
{
    pros::Task td(tm_task);
}



int Ake_task(){
    intake_roller.move_velocity(600);

    return 1;
}

void intake_task(){
    pros::Task Ake(Ake_task);
}



